jQuery(document).ready(function($){
	"use strict";

	$('p:empty').remove();
});